#!/home/tpob/miniconda3/bin/python
import os
from jinja2 import Environment,FileSystemLoader
work_dir='~/Data/Langerhans/'
data_dir=[
    'cellranger_count/FS00',
    'cellranger_count/LC03',
    'cellranger_count/LC06',
    'cellranger_count/LC09',
    'cellranger_count/LC11',
    'cellranger_count/LC14'
]
project_name='Langerhans'
sample_name=[
    'foreskin',
    'lc03',
    'lc06',
    'lc09',
    'lc11',
    'lc14'
]
min_cells=["6"]*6
min_genes=["400"]*6
percentile_mito=["0.95"]*6
percentile_UMI=["0.95"]*6
cluster_resolution=["0.6"]*6
path_of_scripts=r"/data/jwyu/Langerhans/scripts"
original_file_name="20181205_foreskin_mnn.r"
output_prefix="pre_fastmnn_"



env = Environment(loader=FileSystemLoader(path_of_scripts))
t = env.get_template("mnn_script_template.r")
for i in range(6):
    with open(path_of_scripts+r"/"+output_prefix+sample_name[i]+".r", "w") as f:
        f.write(t.render(work_dir=work_dir, data_dir=data_dir[i], project_name=project_name, sample_name=sample_name[i], min_cells=min_cells[i], min_genes=min_genes[i], percentile_UMI=percentile_UMI[i], percentile_mito=percentile_mito[i], cluster_resolution=cluster_resolution[i]))

t = env.get_template("submitt.sh")
for i in range(6):
    with open(path_of_scripts+r"/"+"submitt_"+sample_name[i]+".sh", "w") as f:
        f.write(t.render(sample_name=sample_name[i]))
    os.system("sbatch submitt_"+sample_name[i]+".sh")
