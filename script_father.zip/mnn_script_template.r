work_dir<-"{{work_dir}}"
data_dir<-"{{data_dir}}"
project_name<-"{{project_name}}"
sample_name<-"{{sample_name}}"
min_cells<-{{min_cells}}
min_genes<-{{min_genes}}
percentile_mito<-{{percentile_mito}}
percentile_UMI<-{{percentile_UMI}}
cluster_resolution<-{{cluster_resolution}}




library(Seurat)
suppressPackageStartupMessages(library(scran))
suppressPackageStartupMessages(library(SingleCellExperiment))

setwd(work_dir)

seurat_obj<-Read10X(data.dir = data_dir)

seurat_obj<-CreateSeuratObject(counts = seurat_obj, project = project_name, min.cells = min_cells, min.features = min_genes)

seurat_obj<-RenameCells(object = seurat_obj, new.names = paste0(colnames(seurat_obj),"_", sample_name))

mito.features <- grep(pattern = "^MT-", x = rownames(x = seurat_obj), value = TRUE)
percent.mito <- Matrix::colSums(x = GetAssayData(object = seurat_obj, slot = "counts")[mito.features,
    ])/Matrix::colSums(x = GetAssayData(object = seurat_obj, slot = "counts"))
seurat_obj[["percent.mito"]] <- percent.mito
pdf(file=paste0('figures/',sample_name,'_before_qc.pdf'))
VlnPlot(object = seurat_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mito"),
    ncol = 3, pt.size=1)
dev.off()

seurat_obj<-subset(x = seurat_obj, subset = nFeature_RNA<quantile(seurat_obj@meta.data$nCount_RNA, percentile_mito) &  percent.mito<quantile(seurat_obj@meta.data$percent.mito, percentile_UMI))
pdf(file=paste0('figures/',sample_name,'_after_qc.pdf'))
VlnPlot(object = seurat_obj, features = c("nFeature_RNA", "nCount_RNA", "percent.mito"),
    ncol = 3, pt.size=1)
dev.off()

seurat_obj <- NormalizeData(object = seurat_obj, normalization.method = "LogNormalize",
    scale.factor = 10000)

seurat_obj <- FindVariableFeatures(object = seurat_obj, selection.method = "mean.var.plot", mean.cutoff = c(0.0125, 3), dispersion.cutoff = c(0.5, Inf))
length(x = VariableFeatures(object = seurat_obj))

seurat_obj <- ScaleData(object = seurat_obj, features = rownames(x = seurat_obj), vars.to.regress = c("nCount_RNA",
    "percent.mito"))

seurat_obj<-RunPCA(object = seurat_obj, features = VariableFeatures(object = seurat_obj), Verbose = T)

pdf(file=paste0('figures/',sample_name,'_PC_elbow.pdf'))
ElbowPlot(object = seurat_obj)
dev.off()

PC_to_use <- data.frame(stdev = seurat_obj@reductions$pca@stdev)
PC_to_use$delta <- c(PC_to_use$stdev[1:49] - PC_to_use$stdev[2:50], 0)
PC_to_use$wether_to_use <- PC_to_use$delta >= (PC_to_use$stdev[1] - PC_to_use$stdev[50])/49
PC_to_use$index = 1:50
PC_to_use=1:max(PC_to_use[ PC_to_use$wether_to_use, 'index'])
print("PCs used:\n",PC_to_use)

seurat_obj<-FindNeighbors(object = seurat_obj, dims = PC_to_use)

seurat_obj<-FindClusters(object = seurat_obj, resolution = 0.6, Verbose = T)

seurat_obj<-RunTSNE(object = seurat_obj, dims = PC_to_use)

pdf(file=paste0('figures/',sample_name,'tsne.pdf'))
DimPlot(object = seurat_obj, reduction = 'tsne')
dev.off()
seurat_obj[['orig.ident']]=sample_name

saveRDS(object = seurat_obj, file = file.path('obj_backup/', paste0(sample_name,'_after_tsne.RDS')))

sce_seurat_obj <- SingleCellExperiment(list(counts=as.matrix(seurat_obj@assays$RNA@counts)),
                           colData=DataFrame(seurat_obj[['orig.ident']]),
                           rowData=DataFrame(Symbol=rownames(seurat_obj@assays$RNA@counts)))
set.seed(1000)
clusters <- quickCluster(sce_seurat_obj, method="igraph", min.mean=0.1)
table(clusters)

sce_seurat_obj <- computeSumFactors(sce_seurat_obj, min.mean=0.1, clusters=clusters)
summary(sizeFactors(sce_seurat_obj))
sce_seurat_obj <- normalize(sce_seurat_obj)

sce_seurat_obj<-normalize(sce_seurat_obj)

block <- t(sce_seurat_obj$orig.ident)

fit <- trendVar(sce_seurat_obj, block=block, parametric=FALSE,use.spikes=FALSE)

dec <- decomposeVar(sce_seurat_obj, fit)

sample_dec <- dec
sample_dec$Symbol <- rowData(sce_seurat_obj)$Symbol
sample_dec <- sample_dec[order(sample_dec$bio,decreasing=TRUE),]
print(head(sample_dec))
saveRDS(object = sample_dec, file = file.path('obj_backup/', paste0(sample_name,'pre_mnn_dec.RDS')))
saveRDS(object = sce_seurat_obj, file = file.path('obj_backup/', paste0(sample_name,'pre_mnn.RDS')))
