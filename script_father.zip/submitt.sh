#!/bin/sh
. /home/jwyu/miniconda3/etc/profile.d/conda.sh
conda activate py36
which Rscript
Rscript /home/jwyu/Data/Langerhans/scripts/pre_fastmnn_{{sample_name}}.r
